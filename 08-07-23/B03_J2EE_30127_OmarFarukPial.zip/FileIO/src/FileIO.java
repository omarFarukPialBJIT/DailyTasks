import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileIO {

    public static void createDirectory(Path directoryPath) {
        try {
            Files.createDirectories(directoryPath);
            System.out.println("Directory is created!");
        } catch (IOException e) {
            System.err.println("Failed to create directory!" + e.getMessage());
        }
    }

    public static void createFile(File FirstFile) {
        try {
            if (FirstFile.createNewFile()) {
                System.out.println("File created successfully!");
            } else {
                System.out.println("File already exists!");
            }
        } catch (IOException e) {
            System.err.println("Failed to create file!" + e.getMessage());
        }
    }

    public static void printingFilePath(Path FirstFilePath) {
        try {
            if (Files.notExists(FirstFilePath)) {
                System.out.println("File doesn't exists!");
                return;
            }
            System.out.println("The file path is: " + FirstFilePath);
        } catch (Exception e) {
            System.err.println("Failed to retrieve file!" + e.getMessage());
        }
    }

    public static void writingToFile(Path FirstFilePath, String content) {
        try {
            Files.write(FirstFilePath, content.getBytes());
            System.out.println("File has been written successfully!");
        } catch (Exception e) {
            System.err.println("Failed to write in the file!" + e.getMessage());
        }
    }

    public static void writingToOutputFromFirstFile(Path FirstFilePath, Path directoryPath) {
        FileInputStream sourceStream = null;
        FileOutputStream targetStream = null;
        try {
            sourceStream = new FileInputStream(String.valueOf(FirstFilePath));
            targetStream = new FileOutputStream(directoryPath + "/output.txt");
            int temp;
            while ((temp = sourceStream.read()) != -1) {
                targetStream.write((byte) temp);
            }
            System.out.println("Content of first file has been written to new file!");
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (sourceStream != null) {
                try {
                    sourceStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (targetStream != null) {
                try {
                    targetStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static void main(String[] args) {
        Path directoryPath = Paths.get("C:/Users/BJIT/Desktop/FileIO");
        createDirectory(directoryPath);

        File FirstFile = new File(directoryPath + "/Omar_faruk_pial_30127.txt");
        createFile(FirstFile);


        Path FirstFilePath = Path.of(FirstFile.getAbsolutePath());
        printingFilePath(FirstFilePath);


        String content = "This is sample data for the file!";
        writingToFile(FirstFilePath, content);


        writingToOutputFromFirstFile(FirstFilePath, directoryPath);


    }
}
