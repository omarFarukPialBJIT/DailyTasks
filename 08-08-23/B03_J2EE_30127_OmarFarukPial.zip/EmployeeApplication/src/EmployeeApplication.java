import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class EmployeeApplication implements EmployeeOperations {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Kabir", 24, "IT", 30000));
        employees.add(new Employee("Rahim", 24, "HR", 20000));
        employees.add(new Employee("Munim", 30, "IT", 50000));
        employees.add(new Employee("Mohit", 27, "Marketing", 40000));
        employees.add(new Employee("Kader", 40, "IT", 60000));

        EmployeeApplication employeeApplication = new EmployeeApplication();

        System.out.println("Employees list who works in IT and older than 25 years: ");
        employees.stream().filter(department -> "IT".equals(department.getDepartment())).filter(age -> age.getAge() >= 25).forEach(employee -> System.out.println(employeeApplication.getEmployeeDetails(employee)));

        System.out.println("Average salary: ");
        double averageSalary = employees.stream().map(Employee::getSalary).mapToInt(Integer::intValue).average().orElse(0);
        System.out.println(averageSalary);

        System.out.println("Highest paid employee: ");
        Optional <Employee> highestPaidEmployee = employees.stream().max(Comparator.comparingInt(Employee::getSalary));
        highestPaidEmployee.ifPresent(employee -> System.out.println(employeeApplication.getEmployeeDetails(employee)));

        System.out.println("Sorted employees: ");
        employees.stream().sorted(Comparator.comparingInt(Employee::getAge)).sorted(Comparator.comparingInt(Employee::getSalary).reversed()).forEach(employee -> System.out.println(employeeApplication.getEmployeeDetails(employee)));


    }
}
