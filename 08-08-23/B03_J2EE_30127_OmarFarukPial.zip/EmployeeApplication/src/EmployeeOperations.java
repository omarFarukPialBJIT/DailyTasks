public interface EmployeeOperations {
   default String getEmployeeDetails(Employee employee) {
        return "Name: "+employee.getName()+", Age: "+employee.getAge()+", Department: "+employee.getDepartment()+", Salary: "+employee.getSalary();
    }
}
