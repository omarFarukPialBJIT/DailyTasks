public class Phone extends FeaturePhone implements SmartPhone {

    String model;
    public Phone(String model) {
        this.model = model;
    }

    @Override
    public void call() {
        System.out.println(this.model + " has calling feature!");
    }
    @Override
    public void physicalKeypad() {
        System.out.println(this.model + " has physical keypad!");
    }
    @Override
    public void smallScreen() {
        System.out.println(this.model + " has small screen!");
    }

    @Override
    public void removableBattery() {
        System.out.println(this.model + " has removable battery!");
    }
    @Override
    public void camera() {
        System.out.println(this.model + " has camera!");
    }
    @Override
    public void touchScreen() {
        System.out.println(this.model + " has touchscreen!");
    }
    @Override
    public void wifi() {
        System.out.println(this.model + " has wifi!");
    }
    @Override
    public void largeDisplay() {
        System.out.println(this.model + " has large display!");
    }

    public static void main(String[] args) {

        FeaturePhone nokia1100 = new Phone("Nokia 1100");
        SmartPhone samsungGalaxyS23 = new Phone("Samsung Galaxy S23");
        Phone blackberryKeyOne = new Phone("Blackberry KeyOne");


        System.out.println("Nokia 1100's features: ");
        nokia1100.initFeaturePhone();
        nokia1100.call();
        nokia1100.physicalKeypad();
        nokia1100.removableBattery();
        nokia1100.smallScreen();

        System.out.println("Samsung Galaxy S23 features: ");
        samsungGalaxyS23.initSmartPhone();
        samsungGalaxyS23.call();
        samsungGalaxyS23.camera();
        samsungGalaxyS23.largeDisplay();
        samsungGalaxyS23.touchScreen();
        samsungGalaxyS23.wifi();

        System.out.println("Blackberry KeyOne features: ");
        blackberryKeyOne.call();
        blackberryKeyOne.physicalKeypad();
        blackberryKeyOne.touchScreen();
        blackberryKeyOne.wifi();
        blackberryKeyOne.camera();
        blackberryKeyOne.largeDisplay();

    }
}
