public interface SmartPhone {

    default void initSmartPhone() {
        System.out.println("It is a smart phone!");
    }
    void call();
    void camera();
    void touchScreen();
    void wifi();
    void largeDisplay();
}
