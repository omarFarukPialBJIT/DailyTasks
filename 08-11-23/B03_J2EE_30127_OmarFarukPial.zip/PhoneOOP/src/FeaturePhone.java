public abstract class FeaturePhone {


    public void initFeaturePhone() {
        System.out.println("It is a feature phone!");
    }

    abstract void removableBattery();
    abstract void call();
    abstract void physicalKeypad();
    abstract void smallScreen();
}
